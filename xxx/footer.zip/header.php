<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>YYTuber Checker</title>
  <link rel="stylesheet" href="style.css"/>
</head>
<body>
  <header>
    <div class="logo">
        <a href="index.php">
        <img src="logo.png" style="width: 60%;">    
        </a>
    </div>
    <nav>
      <a href="#">Home</a>
      <a href="about.php">About</a>
      <a href="Blog/">Blog</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>